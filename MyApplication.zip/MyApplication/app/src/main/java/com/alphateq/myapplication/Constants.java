package com.alphateq.myapplication;

public class Constants {
    public static final String What_is_Java="What_is_Java";
    public static final String History_of_Java="History_of_Java";
    public static final String Why_learn_Java="Why_learn_Java";
    public static final String java_variables="java_variables";
    public static final String java_datatypes="java_datatypes";
    public static final String java_conditions="java_conditions";
    public static final String java_loop="java_Loop";
    public static final String java_function="java_function";
    public static final String java_oop="java_oop";
    public static final String class_in_java="class_in_java";
    public static final String java_inheritance="java_inheritance";
    public static final String java_polymorphism="java_polymorphism";
}

package com.alphateq.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final String TAG="MainActivity";
    private Context mContext;
    ArrayList<String> titleArrayList;
    private RecyclerView nRecyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mContext = MainActivity.this;

        titleArrayList = new ArrayList<String>();
        titleArrayList.add(Constants.What_is_Java);
        titleArrayList.add(Constants.History_of_Java);
        titleArrayList.add(Constants.Why_learn_Java);
        titleArrayList.add(Constants.java_variables);
        titleArrayList.add(Constants.java_datatypes);
        titleArrayList.add(Constants.java_conditions);
        titleArrayList.add(Constants.java_loop);
        titleArrayList.add(Constants.java_function);
        titleArrayList.add(Constants.class_in_java);
        titleArrayList.add(Constants.java_oop);
        titleArrayList.add(Constants.java_inheritance);
        titleArrayList.add(Constants.java_polymorphism);

        nRecyclerView = (RecyclerView) findViewById(R.id.title_recycler_view);
        nRecyclerView.setHasFixedSize(true);
        nRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        TitleAdapter adapter = new TitleAdapter(mContext, titleArrayList, new customItemclick() {
            @Override
            public void onItemClick(View v, int position) {
                Intent desIntent = new Intent(MainActivity.this,DescActivity.class);
                desIntent.putExtra("titles: ",titleArrayList.get(position));
                startActivity(desIntent);


                Toast.makeText(mContext,"Clicked "+titleArrayList.get(position),Toast.LENGTH_LONG).show();
            }
        });

        nRecyclerView.setAdapter(adapter);
    }
}

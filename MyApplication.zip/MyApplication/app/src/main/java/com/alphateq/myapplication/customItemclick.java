package com.alphateq.myapplication;

import android.view.View;

public interface customItemclick {
    public void onItemClick(View v, int position);

}
